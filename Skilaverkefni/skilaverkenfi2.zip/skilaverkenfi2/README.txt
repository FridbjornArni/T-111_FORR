submission id: 
https://ru.kattis.com/courses/T-111-PROG/PROG24/assignments/y2y9i6/problems/move?editresubmit=14359993